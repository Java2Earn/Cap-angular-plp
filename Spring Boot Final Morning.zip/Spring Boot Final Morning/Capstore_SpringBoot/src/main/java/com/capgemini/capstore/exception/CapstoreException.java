package com.capgemini.capstore.exception;


public class CapstoreException extends Exception {

	/**
	 * Thrown when an error occur
	 */
	private static final long serialVersionUID = 1L;

	public CapstoreException(String message) {
		super(message);
	}

}
