package com.capgemini.capstore.beans;

import java.sql.Date;
import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "capstore_coupons")
public class Coupon {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "coupon_seq_gen")
	@SequenceGenerator(name = "coupon_seq_gen", initialValue = 10000, sequenceName = "coupon_seq") // to be created
	private long couponId;
	@Column(length = 16, unique = true)
	private String couponCode;
	@Min(1)
	@Max(10000)
	private Float minAmount;
	@Min(1)
	@Max(10000)
	private Float maxAmount;
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(nullable = true)
	private Product product;
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(nullable = true)
	private Category category;
	@Min(0)
	@Max(100)
	private Float discountPercent;
	@NotNull
	private Date generationDate;
	@NotNull
	private Date expiryDate;

	@Override
	public String toString() {
		return "Coupon [couponId=" + couponId + ", couponCode=" + couponCode + ", minAmount=" + minAmount
				+ ", maxAmount=" + maxAmount + ", product=" + product.getProductName() + ", category="
				+ category.getCategoryType() + ", discountPercent=" + discountPercent + ", generationDate="
				+ generationDate + ", expiryDate=" + expiryDate + "]";
	}

	public Coupon() {
		super();
		this.generationDate = new Date(Calendar.getInstance().getTime().getTime());
	}

	public Coupon(long couponId, String couponCode, Float minAmount, Float maxAmount, Product product,
			Category category, Float discountPercent, Date generationDate, Date expiryDate) {
		super();
		this.couponId = couponId;
		this.couponCode = couponCode;
		this.minAmount = minAmount;
		this.maxAmount = maxAmount;
		this.product = product;
		this.category = category;
		this.discountPercent = discountPercent;
		this.generationDate = new Date(Calendar.getInstance().getTime().getTime());
		this.expiryDate = expiryDate;

	}

	public Float getMinAmount() {
		return minAmount;
	}

	public void setMinAmount(Float minAmount) {
		this.minAmount = minAmount;
	}

	public Float getMaxAmount() {
		return maxAmount;
	}

	public void setMaxAmount(Float maxAmount) {
		this.maxAmount = maxAmount;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	public long getCouponId() {
		return couponId;
	}

	public void setCouponId(long couponId) {
		this.couponId = couponId;
	}

	public String getCouponCode() {
		return couponCode;
	}

	public void setCouponCode(String couponCode) {
		this.couponCode = couponCode;
	}

	public Float getDiscountPercent() {
		return discountPercent;
	}

	public void setDiscountPercent(Float discountPercent) {
		this.discountPercent = discountPercent;
	}

	public Date getGenerationDate() {
		return generationDate;
	}

	public void setGenerationDate(Date generationDate) {
		this.generationDate = generationDate;
	}

	public Date getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}

}
