package com.capgemini.capstore.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.capgemini.capstore.beans.Merchant;

@Repository
public interface MerchantRepository extends JpaRepository<Merchant, Long> {

	List<Merchant> findAllByMerchantNameIgnoreCase(String keyword);
	@Query("FROM Merchant as m where lower(m.merchantName) like lower(concat('%', ?1,'%'))")
	List<Merchant> getAllMerchantByMerchantName(String merchantName);
}
