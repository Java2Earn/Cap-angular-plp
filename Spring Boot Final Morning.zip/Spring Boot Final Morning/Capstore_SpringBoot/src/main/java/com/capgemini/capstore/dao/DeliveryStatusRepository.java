package com.capgemini.capstore.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.capstore.beans.DeliveryStatus;
import com.capgemini.capstore.util.OrderStatus;

public interface DeliveryStatusRepository extends JpaRepository<DeliveryStatus, Long> {

	//List<DeliveryStatus> findAllByStatus(OrderStatus status);
	
	


	public List<DeliveryStatus> findAllByStatus(OrderStatus status);
}
