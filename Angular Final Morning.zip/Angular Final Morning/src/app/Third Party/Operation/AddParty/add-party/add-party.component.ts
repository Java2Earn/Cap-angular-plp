import { Component, OnInit } from '@angular/core';
import { Merchant } from 'src/app/entity/Merchant';
import { AdminServiceService } from 'src/app/Service/admin-service.service';

@Component({
  selector: 'app-add-party',
  templateUrl: './add-party.component.html',
  styleUrls: ['./add-party.component.css']
})
export class AddPartyComponent implements OnInit {
  service:AdminServiceService;
  constructor(service:AdminServiceService) { 
    this.service=service;
  }

  ngOnInit() {
  }
  addThirdPartyMerchant(data:any){
    console.log(data);
    this.service.addThirdPartyMerchant(data).then(response => {
      if (response.success == true) {
        alert("Third party merchant added successfully")
      }
    }
      , err => {
        if (err.success != undefined && err.success == false) {
          alert(err.errors);
        }
      });
  }
}
