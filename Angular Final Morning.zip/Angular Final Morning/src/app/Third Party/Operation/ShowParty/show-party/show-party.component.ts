import { Component, OnInit } from '@angular/core';
import { AdminServiceService } from 'src/app/Service/admin-service.service';
import { Merchant } from 'src/app/entity/Merchant';
import { timeout } from 'q';

@Component({
  selector: 'app-show-party',
  templateUrl: './show-party.component.html',
  styleUrls: ['./show-party.component.css']
})
export class ShowPartyComponent implements OnInit {
  merchants: any[] = [];
  service: AdminServiceService;
  constructor(service: AdminServiceService) {
    this.service = service;
    this.getAllThirdPartyMerchants();
    console.log(this.merchants);
  }
  ngOnInit() {

  }
  getAllThirdPartyMerchants() {
    this.service.getAllThirdPartyMerchants().then(response => {
      this.merchants = response.result;
      console.log(response.result);
    }
      , err => {
        if (err.success != undefined && err.success == false) {
          alert(err.errors);
        }
      });
  }
  deleteThirdPartyMerchant(merchantId: number) {
    this.service.deleteThirdPartyMerchant(merchantId).then(response => {
      if (response.result == true) {
        alert("Merchant Removed successfully");
        this.getAllThirdPartyMerchants();
      }
    }
      , err => {
        if (err.success != undefined && err.success == false) {
          alert(err.errors);
        }
      });
  }

}
