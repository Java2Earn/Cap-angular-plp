import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AppComponent } from './app.component';
import { InteractionComponent } from './Interaction/interaction/interaction.component';
import { AddComponent } from './MerchantOperation/operation/add/add.component';
import { HomepageComponent } from './MerchantOperation/homepage/homepage/homepage.component';
import { ShowComponent } from './MerchantOperation/operation/show/show.component';
import { AdminCouponComponent } from './Coupon/admin-coupon/admin-coupon.component';
import { FrontPageComponent } from './ProductOperation/FrontPage/front-page/front-page.component';
import { ProductComponent } from './ProductOperation/operation/product/product.component';
import { AddProductComponent } from './ProductOperation/operation/add-product/add-product.component';
import { UpdateProductComponent } from './ProductOperation/operation/update-product/update-product.component';
import { CategoryComponent } from './ProductOperation/operation/category/category.component';
import { AddCategoryComponent } from './ProductOperation/operation/add-category/add-category.component';
import { FirstPageComponent } from './SearchOperation/FirstPage/first-page/first-page.component';
import { CustomerSearchComponent } from './SearchOperation/operation/customer-search/customer-search.component';
import { MerchantSearchComponent } from './SearchOperation/operation/merchant-search/merchant-search.component';
import { ProductSearchComponent } from './SearchOperation/operation/product-search/product-search.component';
import { FeedpageComponent } from './FeedBack/FeedPage/feedpage/feedpage.component';
import { FeedbackComponent } from './FeedBack/operation/feedback/feedback.component';
import { ForwardComponent } from './FeedBack/operation/forward/forward.component';
import { NotForwardComponent } from './FeedBack/operation/not-forward/not-forward.component';
import { TrackOperationComponent } from './DeliveryStatus/track-operation/track-operation.component';
import { AllCancelledProductsComponent } from './DeliveryStatus/product-tracking-status-operation/all-cancelled-products/all-cancelled-products.component';
import { AllDeliveredProductsComponent } from './DeliveryStatus/product-tracking-status-operation/all-delivered-products/all-delivered-products.component';
import { AllPackedProductsComponent } from './DeliveryStatus/product-tracking-status-operation/all-packed-products/all-packed-products.component';
import { AllPlacedProductsComponent } from './DeliveryStatus/product-tracking-status-operation/all-placed-products/all-placed-products.component';
import { AllReturnedProductsComponent } from './DeliveryStatus/product-tracking-status-operation/all-returned-products/all-returned-products.component';
import { AllShippedProductsComponent } from './DeliveryStatus/product-tracking-status-operation/all-shipped-products/all-shipped-products.component';
import { ThirdPageComponent } from './Third Party/ThirdPage/third-page/third-page.component';
import { AddPartyComponent } from './Third Party/Operation/AddParty/add-party/add-party.component';
import { ShowPartyComponent } from './Third Party/Operation/ShowParty/show-party/show-party.component';
import { CartManagementComponent } from './cart-management/cart-management.component';
import { ShowCouponComponent } from './Coupon/show-coupon/show-coupon.component';
import { SentComponent} from './FeedBack/operation/sent/sent.component';








const routes: Routes = [{
  path: '', redirectTo: 'app-interaction', pathMatch: 'full'
},
{
  path: 'app-root',
  component: AppComponent
},
{
  path: 'app-interaction',
  component: InteractionComponent
},

{
  path: 'app-homepage/app-add',
  component: AddComponent
},
{
  path: 'app-homepage',
  component: HomepageComponent
},

{
  path: 'app-homepage/app-show',
  component: ShowComponent
},

{
  path: 'app-admin-coupon',
  component: AdminCouponComponent
},
{
  path: 'app-show-coupon',
  component: ShowCouponComponent
},
{
  path: 'app-front-page', //add the path and component of employee 
  component: FrontPageComponent
},
{
  path: 'app-front-page/app-product', //add the path and component of employee 
  component: ProductComponent
},
{
  path: 'app-front-page/app-add-product',  //add the path and component of add-employee
  component: AddProductComponent
},
{
  path: 'app-front-page/app-update-product',  //add the path and component of add-employee
  component: UpdateProductComponent
},
{
  path: 'app-front-page/app-category', //add the path and component of employee 
  component: CategoryComponent
},
{
  path: 'app-front-page/app-add-category',  //add the path and component of add-employee
  component: AddCategoryComponent
},
{
  path: 'app-first-page',
  component: FirstPageComponent
},
{
  path: 'app-first-page/app-customer-search',
  component: CustomerSearchComponent
},
{
  path: 'app-first-page/app-merchant-search',
  component: MerchantSearchComponent
},
{
  path: 'app-first-page/app-product-search',
  component: ProductSearchComponent
},
{
  path: 'app-feedpage',
  component: FeedpageComponent
},
{
  path: 'app-feedpage/app-feedback',
  component: FeedbackComponent
},
{
  path: 'app-feedpage/app-forward',
  component: ForwardComponent
},
{
  path: 'app-feedpage/app-not-forward',
  component: NotForwardComponent
},{
  path: 'app-feedpage/app-sent',
  component: SentComponent
},
{
  path: 'app-track-operation',
  component: TrackOperationComponent
},
{
  path: 'app-track-operation/app-all-cancelled-products',
  component: AllCancelledProductsComponent
},
{
  path: 'app-track-operation/app-all-delivered-products',
  component: AllDeliveredProductsComponent
},
{
  path: 'app-track-operation/app-all-packed-products',
  component: AllPackedProductsComponent
},
{
  path: 'app-track-operation/app-all-placed-products',
  component: AllPlacedProductsComponent
},
{
  path: 'app-track-operation/app-all-returned-products',
  component: AllReturnedProductsComponent
},
{
  path: 'app-track-operation/app-all-shipped-products',
  component: AllShippedProductsComponent
},
{
  path: 'app-third-page',
  component: ThirdPageComponent
},
{
  path: 'app-third-page/app-add-party',
  component: AddPartyComponent
},
{
  path: 'app-third-page/app-show-party',
  component: ShowPartyComponent
},
{
  path: 'app-cart-management',
  component: CartManagementComponent
}


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
