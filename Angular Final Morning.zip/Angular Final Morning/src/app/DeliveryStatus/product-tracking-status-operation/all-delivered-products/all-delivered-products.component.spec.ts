import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AllDeliveredProductsComponent } from './all-delivered-products.component';

describe('AllDeliveredProductsComponent', () => {
  let component: AllDeliveredProductsComponent;
  let fixture: ComponentFixture<AllDeliveredProductsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AllDeliveredProductsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AllDeliveredProductsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
