import { Component, OnInit } from '@angular/core';
import { AdminServiceService } from 'src/app/Service/admin-service.service';
import { Data } from '../../../Entity/Data';


@Component({
  selector: 'app-all-placed-products',
  templateUrl: './all-placed-products.component.html',
  styleUrls: ['./all-placed-products.component.css']
})
export class AllPlacedProductsComponent implements OnInit {

  service: AdminServiceService;
  constructor(service: AdminServiceService) { this.service = service }
  response: any;
  ngOnInit() {
    this.fetchDeliveryStatus();

  }
  fetchDeliveryStatus() {
    this.service.fetchDeliveryStatus('placed').then(response => {
    this.response = response.result;
      console.log(response);
    }
      , err => {
        if (err.success != undefined && err.success == false) {
          alert(err.errors);
        }
      });
  }
  changeStatus(id)
  {
    this.service.updateDeliveryStatus(id,'packed').then(response => {
      window.location.reload();
      }
        , err => {
          if (err.success != undefined && err.success == false) {
            alert(err.errors);
          }
        });
  }
}
