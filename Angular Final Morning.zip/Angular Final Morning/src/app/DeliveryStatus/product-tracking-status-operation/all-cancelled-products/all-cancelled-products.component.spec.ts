import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AllCancelledProductsComponent } from './all-cancelled-products.component';

describe('AllCancelledProductsComponent', () => {
  let component: AllCancelledProductsComponent;
  let fixture: ComponentFixture<AllCancelledProductsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AllCancelledProductsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AllCancelledProductsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
