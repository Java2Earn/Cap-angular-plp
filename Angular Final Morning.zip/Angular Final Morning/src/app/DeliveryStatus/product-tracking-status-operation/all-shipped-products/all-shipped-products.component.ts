import { Component, OnInit } from '@angular/core';
import { AdminServiceService } from 'src/app/Service/admin-service.service';
import { Data } from 'src/app/Entity/Data';


@Component({
  selector: 'app-all-shipped-products',
  templateUrl: './all-shipped-products.component.html',
  styleUrls: ['./all-shipped-products.component.css']
})
export class AllShippedProductsComponent implements OnInit {


  service: AdminServiceService;
  constructor(service: AdminServiceService) { this.service = service }
  response: any;
  ngOnInit() {
    this.fetchDeliveryStatus();

  }
  fetchDeliveryStatus() {
    this.service.fetchDeliveryStatus('shipped').then(response => {
    this.response = response.result;
      console.log(response);
    }
      , err => {
        if (err.success != undefined && err.success == false) {
          alert(err.errors);
        }
      });
  }
  changeStatus(id)
  {
    this.service.updateDeliveryStatus(id,'delivered').then(response => {
      window.location.reload();
      }
        , err => {
          if (err.success != undefined && err.success == false) {
            alert(err.errors);
          }
        });
  }
}
