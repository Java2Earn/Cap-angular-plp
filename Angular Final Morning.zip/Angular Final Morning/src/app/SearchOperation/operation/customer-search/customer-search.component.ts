import { Component, OnInit } from '@angular/core';
import { AdminServiceService } from 'src/app/Service/admin-service.service';
import { Customer } from 'src/app/Entity/customer';


@Component({
  selector: 'app-customer-search',
  templateUrl: './customer-search.component.html',
  styleUrls: ['./customer-search.component.css']
})
export class CustomerSearchComponent implements OnInit {
service:AdminServiceService;
  constructor(service:AdminServiceService)
   {
     this.service=service;
    }
customer:Customer[]=[];
  ngOnInit() {
  }

  searchCustomer(data:any){
    this.service.searchByCustomerName(data.customerName).then(response => {
      this.customer = response.result;
    }
      , err => {
        if (err.success != undefined && err.success == false) {
          alert(err.errors);
        }
      });
  }
}
