export class Coupon{
    static COLUMNS=['couponId','couponCode','minAmount','maxAmount','discountPercent','generationDate','expiryDate'];
    couponId:number;
    couponCode:string;
    minAmount:number;
    maxAmount:string;
    discountPercent:number;
    generationDate:number;
    expiryDate:number;
    constructor(couponId:number,couponCode:string,minAmount:number,maxAmount:string,discountPercent:number,generationDate:number,expiryDate:number)
    {
    this.couponId=couponId;
    this.couponCode=couponCode;
    this.minAmount=minAmount;
    this.maxAmount=maxAmount;
    this.discountPercent=discountPercent;
    this.generationDate=generationDate;
    this.expiryDate=expiryDate;
    }
}