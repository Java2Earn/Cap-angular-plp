export class Product{
  productId:number;
  productDescription:string;
  productDiscount:number;
  productName:string;
  productPrice:number;
  productQuantity:number;
  
  constructor( productId:number,

    productDescription:string,
    productDiscount:number,
    productName:string,
    productPrice:number,
    productQuantity:number){
      this.productId=productId;
      this.productDescription=productDescription;
      this.productDiscount=productDiscount;
      this.productName=productName;
      this.productPrice=productPrice;
      this.productQuantity=productQuantity;
      
    }

}