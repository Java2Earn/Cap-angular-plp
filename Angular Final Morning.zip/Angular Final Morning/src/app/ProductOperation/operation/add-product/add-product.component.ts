import { Component, OnInit } from '@angular/core';
import { Product } from 'src/app/Entity/Product';
import { AdminServiceService } from 'src/app/Service/admin-service.service';

@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.css']
})
export class AddProductComponent implements OnInit {
  service: AdminServiceService;
  constructor(service: AdminServiceService) {
    this.service = service;
  }

  ngOnInit() {
  }

  addProduct(data) {
    let createdProduct = new Product(0, data.productDescription, data.productDiscount, data.productName, data.productPrice, data.productQuantity);
    this.service.addProduct(createdProduct).then(response => {
      if (response.success == true) {
        alert("Product added successfully");
      }
    }
      , err => {
        if (err.success != undefined && err.success == false) {
          alert(err.errors);
          console.log(err.error);
        }
      });
  }
}
