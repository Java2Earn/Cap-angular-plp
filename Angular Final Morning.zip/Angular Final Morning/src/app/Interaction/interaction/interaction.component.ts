import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-interaction',
  templateUrl: './interaction.component.html',
  styleUrls: ['./interaction.component.css']
})
export class InteractionComponent implements OnInit {


  router:Router;
  constructor(router:Router){
   this.router=router;
  }

  navigateToHomePage(){
    console.log("----------------")
    this.router.navigate(['/app-homepage']);
  }
  navigateToCoupon(){
    console.log("----------------")
  this.router.navigate(['/app-admin-coupon']);
  }
  navigateToProduct(){
    console.log("----------------")
  this.router.navigate(['/app-front-page']);
  }
  navigateToSearch(){
    console.log("----------------")
  this.router.navigate(['/app-first-page']);
  }
  navigateToFeedBack(){
    console.log("----------------")
  this.router.navigate(['/app-feedpage']);
  }
  navigateToTrack()
  {
    console.log("----------------")
    this.router.navigate(['/app-track-operation']);
  }
  navigateToThirdPage(){
    console.log("----------------")
    this.router.navigate(['/app-third-page']); 
  }
  navigateToCart(){
    console.log("----------------")
    this.router.navigate(['/app-cart-management']); 
  }
  ngOnInit() 
  {

      }

}
