import { Component, OnInit } from '@angular/core';
import { AdminServiceService } from 'src/app/Service/admin-service.service';



@Component({
  selector: 'app-feedback',
  templateUrl: './feedback.component.html',
  styleUrls: ['./feedback.component.css']
})
export class FeedbackComponent implements OnInit {
  merchantFeedbacks: any;
  constructor(private service: AdminServiceService) { }
adminComment:any;

  ngOnInit() {
    this.getMerchantFeedbacks();
  }
  getMerchantFeedbacks() {
    this.service.getMerchantFeedbacks('not_forwarded').then(response => {
      this.merchantFeedbacks = response.result;
      console.log(response);
    }
      , err => {
        if (err.success != undefined && err.success == false) {
          alert(err.errors);
        }
      });
  }
  changeFeedbackStatus(feedbackObject:any)
  {
    feedbackObject.adminComment = this.adminComment;
    feedbackObject.status = "FORWARDED";
    this.service.changeMerchantFeedbackStatus(feedbackObject).then(response => {
     if(response.success== true)
     {
       alert("Feedback forwarded successfully");
       window.location.reload();
     }
    }
      , err => {
        if (err.success != undefined && err.success == false) {
          alert(err.errors);
        }
      });
  }
}
