import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NotForwardComponent } from './not-forward.component';

describe('NotForwardComponent', () => {
  let component: NotForwardComponent;
  let fixture: ComponentFixture<NotForwardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NotForwardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NotForwardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
