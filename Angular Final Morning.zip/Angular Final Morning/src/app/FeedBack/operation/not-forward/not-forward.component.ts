import { Component, OnInit } from '@angular/core';
import { AdminServiceService } from 'src/app/Service/admin-service.service';

@Component({
  selector: 'app-not-forward',
  templateUrl: './not-forward.component.html',
  styleUrls: ['./not-forward.component.css']
})
export class NotForwardComponent implements OnInit {
  merchantFeedbacks: any;
  constructor(private service: AdminServiceService) { }

  ngOnInit() {
    this.getMerchantFeedbacks();
  }
  getMerchantFeedbacks() {
    this.service.getMerchantFeedbacks('RESPONDED') .then(response => {
      this.merchantFeedbacks = response.result;
      console.log(response);
    }
      , err => {
        if (err.success != undefined && err.success == false) {
          alert(err.errors);
        }
      });
  }
  changeFeedbackStatus(feedbackObject:any)
  {
    feedbackObject.status = "SENT_TO_CUSTOMER";
    this.service.changeMerchantFeedbackStatus(feedbackObject).then(response => {
     if(response.success== true)
     {
       alert("Response Sent to Customer successfully");
       window.location.reload();
     }
    }
      , err => {
        if (err.success != undefined && err.success == false) {
          alert(err.errors);
        }
      });
  }
}
