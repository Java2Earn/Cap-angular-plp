import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AdminServiceService } from 'src/app/Service/admin-service.service';
import { Coupon } from 'src/app/Entity/Coupon';


@Component({
  selector: 'app-admin-coupon',
  templateUrl: './admin-coupon.component.html',
  styleUrls: ['./admin-coupon.component.css']
})
export class AdminCouponComponent implements OnInit {
coupons:Coupon[]=[];
  service: AdminServiceService;
  addedCoupon: Coupon;
  couponGenerate: FormGroup;
  submitted = false;

  constructor(private formBuilder: FormBuilder, service: AdminServiceService) {
    this.service = service;
  }

  ngOnInit() {
    this.couponGenerate = this.formBuilder.group({
      couponCode: ['', Validators.required],
      minAmount: ['', Validators.required],
      maxAmount: ['', Validators.required],
      discountPercent: ['', Validators.required],
      generationDate: ['', Validators.required],
      expiryDate: ['', Validators.required],

    });
  }

  // convenience getter for easy access to form fields
  get f() { return this.couponGenerate.controls; }


  addCoupon() {
    let data = { couponCode: this.f.couponCode.value, minAmount: this.f.minAmount.value, discountPercent: this.f.discountPercent.value, maxAmount: this.f.maxAmount.value, expiryDate: this.f.expiryDate.value };
    this.submitted = true;
    this.service.addCoupon(data).then(response => {

      if (response.success == true) {
        alert("Copon added successfully");
      }
    }
      , err => {
        if (err.success != undefined && err.success == false) {
          alert(err.errors);
        }
      });
  }
  getAllCoupons() {
    this.service.getAllCoupons().then(response => {
      this.coupons = response.result;
      console.log(this.coupons);
    }
      , err => {
        if (err.success != undefined && err.success == false) {
          alert(err.errors);
        }
      });
  }
  deleteCoupon(id) {
    this.service.deleteCoupon(id).then(response => {
      if (response.success == true) {
        alert("Copon deleted successfully");
      }
    }
      , err => {
        if (err.success != undefined && err.success == false) {
          alert(err.errors);
        }
      });
  }
}

