package com.capgemini.capstore.exceptions;

public class UnsuccessfullOperations extends RuntimeException{

	public UnsuccessfullOperations() {
		super();
		// TODO Auto-generated constructor stub
	}

	public UnsuccessfullOperations(String arg0, Throwable arg1, boolean arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

	public UnsuccessfullOperations(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public UnsuccessfullOperations(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public UnsuccessfullOperations(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}
	

}
