package com.cg.capStore.searchStepDefinition;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(plugin = {"pretty"},features = "C:\\Users\\harana\\Desktop\\PLP\\FinalCapstore\\CapStore\\src\\test\\resources\\search.feature", glue = "") public class SearchTestRunner {

}