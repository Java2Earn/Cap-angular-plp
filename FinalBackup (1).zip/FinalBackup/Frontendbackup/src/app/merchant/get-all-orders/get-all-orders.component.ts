import { Component, OnInit } from '@angular/core';
import { MerchantServiceService } from 'src/app/services/merchant-service.service';
import { Order } from 'src/app/Models/Order';
import { Route, Router } from '@angular/router';

@Component({
  selector: 'app-get-all-orders',
  templateUrl: './get-all-orders.component.html',
  styleUrls: ['./get-all-orders.component.css']
})
export class GetAllOrdersComponent implements OnInit {

  orders:Order[] = []
  constructor(private merchantService:MerchantServiceService,private router:Router) {
    this.merchantService = merchantService;
    this.router = router;
   }

  ngOnInit() {
    let obj = this.merchantService.getAllOrders();
    obj.subscribe((data) => {
      console.log(data);
      if (data.length == 0) {
        alert("No Data")
        this.router.navigate(['merchant']);
      }
      else {
      this.orders = data;
      }
    })

  }

}
