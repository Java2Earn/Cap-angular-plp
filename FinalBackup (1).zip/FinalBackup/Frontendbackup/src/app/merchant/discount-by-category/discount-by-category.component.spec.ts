import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DiscountByCategoryComponent } from './discount-by-category.component';

describe('DiscountByCategoryComponent', () => {
  let component: DiscountByCategoryComponent;
  let fixture: ComponentFixture<DiscountByCategoryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DiscountByCategoryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DiscountByCategoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
