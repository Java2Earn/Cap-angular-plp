import { Product } from './Product';

export class Stock{
    stockId:number;
    product:Product;
    available:number;
    totalQuantity:number;

    constructor(product:Product,available:number,totalQuantity:number){
        this.product = product;
        this.available = available;
        this.totalQuantity = totalQuantity;
    }

}