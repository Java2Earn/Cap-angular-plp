import { Product } from './Product';
import { Invoice } from './Invoice';

export class Order{
    orderId:number;
    discountTotal:number;
    quantity:number;
    totalAmount:number;
    invoice:Invoice;
    product:Product;
    
    constructor(orderId:number,discountTotal:number,quantity:number,totalAmount:number,invoice:Invoice,product:Product){
        this.orderId = orderId;
        this.discountTotal = discountTotal;
        this.totalAmount = totalAmount;
        this.invoice = invoice;
        this.product = product;
    }
}
