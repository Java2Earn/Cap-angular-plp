import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MerchantComponent } from './merchant/merchant.component';
import { MerchantProfileComponent } from './merchant/merchant-profile/merchant-profile.component';
import { AddProductComponent } from './merchant/add-product/add-product.component';
import { DiscountByCategoryComponent } from './merchant/discount-by-category/discount-by-category.component';
import { GetAllOrdersComponent } from './merchant/get-all-orders/get-all-orders.component';
import { FeedbackResponseComponent } from './merchant/feedback-response/feedback-response.component';


const routes: Routes = [
  { path: '', redirectTo: 'merchant', pathMatch: 'full' },
  { path: 'merchant', component:MerchantComponent 
    // children:[{
    //   path:'merchantOperations' , component:MerchantOperationsComponent 
    // }]  
  },
  { path:'merchant/merchantProfile' , component:MerchantProfileComponent},
  { path:'merchant/addProduct' , component:AddProductComponent},
  { path:'merchant/discountByCategory' , component:DiscountByCategoryComponent},
  { path:'merchant/getAllOrders' , component:GetAllOrdersComponent},
  { path:'merchant/feedbackResponse' , component:FeedbackResponseComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
