import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MerchantComponent } from './merchant/merchant.component';
import { MerchantProfileComponent } from './merchant/merchant-profile/merchant-profile.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MerchantServiceService } from './services/merchant-service.service';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { AddProductComponent } from './merchant/add-product/add-product.component';
import { GetAllOrdersComponent } from './merchant/get-all-orders/get-all-orders.component';
import { DiscountByCategoryComponent } from './merchant/discount-by-category/discount-by-category.component';
import { FeedbackResponseComponent } from './merchant/feedback-response/feedback-response.component';



@NgModule({
  declarations: [
    AppComponent,
    MerchantComponent,
    MerchantProfileComponent,
    AddProductComponent,
    GetAllOrdersComponent,
    DiscountByCategoryComponent,
    FeedbackResponseComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [MerchantServiceService,HttpClient],
  bootstrap: [AppComponent]
})
export class AppModule { }
