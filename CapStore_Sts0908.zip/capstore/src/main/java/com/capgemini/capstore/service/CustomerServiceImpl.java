package com.capgemini.capstore.service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.capstore.beans.AccountDetail;
import com.capgemini.capstore.beans.Cart;
import com.capgemini.capstore.beans.Customer;
import com.capgemini.capstore.beans.DeliveryStatus;
import com.capgemini.capstore.beans.Merchant;
import com.capgemini.capstore.beans.MerchantFeedback;
import com.capgemini.capstore.beans.Order;
import com.capgemini.capstore.beans.Product;
import com.capgemini.capstore.beans.ProductFeedback;
import com.capgemini.capstore.beans.Stock;
import com.capgemini.capstore.beans.WishList;
import com.capgemini.capstore.dao.AccountDao;
import com.capgemini.capstore.dao.CartDao;
import com.capgemini.capstore.dao.CustomerDao;
import com.capgemini.capstore.dao.DeliveryStatusDao;
import com.capgemini.capstore.dao.MerchantDao;
import com.capgemini.capstore.dao.MerchantFeedBackDao;
import com.capgemini.capstore.dao.OrderDao;
import com.capgemini.capstore.dao.ProductDao;
import com.capgemini.capstore.dao.ProductFeedbackDao;
import com.capgemini.capstore.dao.StockDao;
import com.capgemini.capstore.dao.WishlistDao;
import com.capgemini.capstore.exception.CartNotFoundException;
import com.capgemini.capstore.exception.CustomerCreationException;
import com.capgemini.capstore.exception.CustomerNotFoundException;
import com.capgemini.capstore.exception.MerchantNotFoundException;
import com.capgemini.capstore.exception.ProductFeedBackException;
import com.capgemini.capstore.exception.ProductNotFoundException;
import com.capgemini.capstore.exception.StockNotPresentException;
import com.capgemini.capstore.exception.WishListNotFoundException;
import com.capgemini.capstore.util.OrderStatus;

@Service("custService")
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	CustomerDao custDao;
	@Autowired
	MerchantFeedBackDao merchantFeedbackDao;
	@Autowired
	ProductDao productDao;
	@Autowired
	ProductFeedbackDao productFeedbackDao;
	@Autowired
	MerchantDao merchantDao;
	@Autowired
	CartDao cartDao;
	@Autowired
	StockDao stockDao;
	@Autowired
	WishlistDao wishListDao;
	@Autowired
	OrderDao orderDao;
	@Autowired
	DeliveryStatusDao deliveryDao;
	@Autowired
	AccountDao accountDao;

	@Override
	public boolean createAccount(Customer cust) {
		Customer customer = custDao.save(cust);
		if (customer == null) {
			throw new CustomerCreationException("Customer Not Created!!");
		}

		return true;
	}

	@Override
	public void editCustProfile(Long customerId, String customerName, String customerContactNo,
			String customerAddress) {
		Optional<Customer> cust = custDao.findById(customerId);

		if (!cust.isPresent()) {
			throw new CustomerNotFoundException("Customer Not Found!!");
		} else {
			Customer tempCust = cust.get();
			tempCust.setCustomerName(customerName);
			tempCust.setCustomerContactNo(customerContactNo);
			tempCust.setCustomerAddress(customerAddress);
			custDao.save(tempCust);

		}
	}

	@Override
	public boolean addProduct(Product product) {
		if (productDao.save(product) != null)
			return true;
		else
			return false;
	}

	@Override
	public boolean merchantFeedback(MerchantFeedback merch) {

		Optional<Merchant> optional = merchantDao.findById(merch.getId());
		if (!optional.isPresent()) {
			throw new MerchantNotFoundException("Merchant Not Found!!");
		} else {
			merchantFeedbackDao.save(merch);
			return true;
		}
	}

	@Override
	public ProductFeedback productFeedback(long productId, long customerId, String feedBack, int rating) {

		ProductFeedback prodFB = new ProductFeedback();
		Optional<Product> optional = productDao.findById(productId);
		if (!optional.isPresent()) {
			throw new ProductNotFoundException("Product Not Found!!");
		}
		Product product = optional.get();
		prodFB.setProduct(product);
		Optional<Customer> optional2 = custDao.findById(customerId);
		if (!optional2.isPresent()) {
			throw new CustomerNotFoundException("Customer Not Found!!");
		}
		Customer customer = optional2.get();
		prodFB.setCustomer(customer);
		prodFB.setFeedBack(feedBack);
		prodFB.setRating(rating);
		ProductFeedback proFeed = productFeedbackDao.save(prodFB);
		if (proFeed == null) {
			throw new ProductFeedBackException("SomeThing Happened Will Giving FeedBack");
		}
		return proFeed;
	}

	@Override
	public void deleteCartProduct(Long cartId) {
		cartDao.deleteById(cartId);

	}

	@Override
	public List<Cart> findAllCartProducts() {
		return cartDao.findAll();
	}

	@Override
	public boolean addToCartFromProductPage(Long customerId, Long productId) {
		if (!findProductQuantity(productId, 1)) {
			throw new StockNotPresentException("Stock Not Present!!");
		} else {
			Optional<Customer> cust = custDao.findById(customerId);
			if (!cust.isPresent()) {
				throw new CustomerNotFoundException("Customer Not Found!!");
			}
			Optional<Product> prod = productDao.findById(productId);
			if (!prod.isPresent()) {
				throw new ProductNotFoundException("Product Not Found!!");
			}
			if (cust.isPresent() && prod.isPresent()) {
				Cart cart = new Cart();
				cart.setCustomer(cust.get());
				cart.setProducts(prod.get());
				cart.setProductQty(1);
				Cart kart = cartDao.save(cart);
				if (kart == null) {
					throw new CartNotFoundException("Can Not be inserted in the Cart");
				}
			}
			return true;
		}
	}

	@Override
	public boolean findProductQuantity(long productId, int quantity) {
		Optional<Product> optional = productDao.findById(productId);
		Product product = optional.get();
		Optional<Stock> stock = stockDao.getStockByProductId(product);
		if (stock.get().getAvailable() < quantity) {
			return false;
		} else
			return true;

	}

	@Override
	public void addtoWishListFromProductPage(Long customerId, Long productId) {

		Optional<Customer> cust = custDao.findById(customerId);
		if (!cust.isPresent()) {
			throw new CustomerNotFoundException("Customer Not Found!!");
		}
		Customer customer = cust.get();
		Optional<Product> prod = productDao.findById(productId);
		if (!prod.isPresent()) {
			throw new ProductNotFoundException("Product Not Found!!");
		}
		Product product = prod.get();
		if (cust.isPresent() && prod.isPresent()) {
			WishList wish = new WishList();
			wish.setCustomer(customer);
			wish.setProducts(product);
			WishList list = wishListDao.save(wish);
			if (list == null) {
				throw new WishListNotFoundException("Can Not be inserted in the WishList");
			}
		}
	}

	@Override
	public void addToCartFromWishList(Long wishlistId) {

		Optional<WishList> wishList = wishListDao.findById(wishlistId);
		if (!wishList.isPresent()) {
			throw new WishListNotFoundException("WishList Not Found!!");
		}
		Product tempProd = wishList.get().getProducts();
		if (tempProd == null) {
			throw new ProductNotFoundException("Product Not Found!!");
		}
		long prodId = tempProd.getProductId();
		Customer tempCust = wishList.get().getCustomer();

		if (tempCust == null) {
			throw new CustomerNotFoundException("Customer Not Found!!");
		}
		long custId = tempCust.getCustomerId();
		Optional<Product> prod = productDao.findById(prodId);
		if (!prod.isPresent()) {
			throw new ProductNotFoundException("Product Not Found!!");
		}
		Optional<Customer> cust = custDao.findById(custId);
		if (!cust.isPresent()) {
			throw new CustomerNotFoundException("Customer Not Found!!");
		}
		if (cust.isPresent() && prod.isPresent()) {
			Cart cart = new Cart();
			cart.setProducts(prod.get());
			cart.setProductQty(1);
			cart.setCustomer(cust.get());
			Cart kart = cartDao.save(cart);
			if (kart == null) {
				throw new CartNotFoundException("Can Not be inserted in the Cart");
			}
			wishListDao.deleteById(wishlistId);
		}
	}

	@Override
	public void deleteFromWishList(Long wishlistId) {
		wishListDao.deleteById(wishlistId);
	}

	@Override
	public void addToWishListFromCart(Long cartId) {
		Optional<Cart> cart = cartDao.findById(cartId);
		if (!cart.isPresent()) {
			throw new CartNotFoundException("Cart Not Found!!");
		}

		Product tempProd = cart.get().getProducts();
		if (tempProd == null) {
			throw new ProductNotFoundException("Product Not Found!!");
		}
		long prodId = tempProd.getProductId();
		Customer tempCust = cart.get().getCustomer();
		if (tempCust == null) {
			throw new CustomerNotFoundException("Customer Not Found!!");
		}
		long custId = tempCust.getCustomerId();
		Optional<Product> prod = productDao.findById(prodId);
		if (!prod.isPresent()) {
			throw new ProductNotFoundException("Product Not Found!!");
		}
		Optional<Customer> cust = custDao.findById(custId);
		if (!cust.isPresent()) {
			throw new CustomerNotFoundException("Customer Not Found!!");
		}
		if (cust.isPresent() && prod.isPresent()) {
			WishList wishList = new WishList();
			wishList.setProducts(prod.get());
			wishList.setCustomer(cust.get());
			WishList list = wishListDao.save(wishList);
			if (list == null) {
				throw new WishListNotFoundException("Can Not be inserted in the WishList");
			}
			cartDao.deleteById(cartId);
		}
	}

	@Override
	public List<WishList> getWishListById(Long customerId) {
		return wishListDao.getWishesById(customerId);
	}

	@Override
	public List<Cart> findAllCartProductsById(Long customerId) {
		return cartDao.findCartByCustomerId(customerId);
	}

	/*-----------------------------------------------------------------------------------------*/

	public List<DeliveryStatus> getDeliveryOrder(long customerId) {
		return deliveryDao.getDeliveryOrder(customerId);
	}

	@Override
	public List<Order> getAllOrder(long customerId) {
		return orderDao.getAllOrder(customerId);
	}

	public DeliveryStatus returnFromDelivery(long id, long customerId) throws java.text.ParseException {
		DeliveryStatus delivery = null;
		Optional<DeliveryStatus> TempDeliveryStatus = deliveryDao.findById(id);
		OrderStatus delStatus = TempDeliveryStatus.get().getStatus();
		if ((delStatus != OrderStatus.DELIVERED))/* Change exp */
		{
			throw new CustomerNotFoundException("cannot return a product that has not yet been delivered");
		} else {
			Optional<DeliveryStatus> stat = deliveryDao.findById(id);
			delivery = stat.get();
			Date d = new Date();
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			String currentDate = sdf.format(d);
			Date delivered = delivery.getDeliveryDate();
			String deliveredDate = sdf.format(delivered);
			Date dateBefore = sdf.parse(currentDate);
			if (dateBefore == null) { /* Change exp */
				throw new CustomerNotFoundException("Cannot get date");
			}
			Date dateAfter = sdf.parse(deliveredDate);
			long difference = dateBefore.getTime() - dateAfter.getTime();
			int daysBetween = (int) (difference / (1000 * 60 * 60 * 24));
			OrderStatus s = delivery.getStatus();
			if (s.toString().equals("DELIVERED") && (daysBetween < 15)) {
				delivery.setStatus(OrderStatus.RETURNED);
				deliveryDao.save(delivery);
				AccountDetail account = accountDao.getAccountDetails(customerId);
				int amount = (int) delivery.getOrder().getTotalAmount();
				int balance = account.getBalance();
				account.setBalance(amount + balance);
				accountDao.save(account);
			}
			 System.out.println(delivery);
			return delivery;
			
		}

	
	}

	public List<DeliveryStatus> refundSummary(long customerId) {
		return deliveryDao.getDeliverd(customerId, OrderStatus.RETURNED);
	}

	/*-----------------------------------------------------------------------------------------*/

}
