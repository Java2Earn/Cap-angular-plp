package com.capgemini.capstore.service;

import java.text.ParseException;
import java.util.List;

import org.springframework.web.bind.annotation.PathVariable;

import com.capgemini.capstore.beans.Cart;
import com.capgemini.capstore.beans.Customer;
import com.capgemini.capstore.beans.DeliveryStatus;
import com.capgemini.capstore.beans.MerchantFeedback;
import com.capgemini.capstore.beans.Order;
import com.capgemini.capstore.beans.Product;
import com.capgemini.capstore.beans.ProductFeedback;
import com.capgemini.capstore.beans.WishList;

public interface CustomerService {

	void editCustProfile(Long customerId, String customerName, String customerContactNo, String customerAddress);

	boolean createAccount(Customer cust);

	public boolean merchantFeedback(MerchantFeedback merch);

	public ProductFeedback productFeedback(long productId, long customerId, String feedBack, int rating);

	void deleteCartProduct(Long cartId);

	boolean addToCartFromProductPage(Long customerId, Long productId);

	List<Cart> findAllCartProducts();

	void addtoWishListFromProductPage(Long customerId, Long productId);

	void addToCartFromWishList(Long wishlistId);

	void deleteFromWishList(Long wishlistId);

	boolean addProduct(Product product);

	void addToWishListFromCart(Long cartId);
	
	
	List<WishList> getWishListById(Long customerId);
	
	List<Cart> findAllCartProductsById(Long customerId);

	boolean findProductQuantity(long productId, int quantity);
	
	
	
	
	
	List<Order> getAllOrder(@PathVariable long customerId);
	List<DeliveryStatus> getDeliveryOrder(@PathVariable long customerId);
	DeliveryStatus returnFromDelivery(@PathVariable long id, @PathVariable long customerId) throws ParseException;
	List<DeliveryStatus> refundSummary(@PathVariable long customerId);

}
