package com.capgemini.capstore.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.capgemini.capstore.beans.DeliveryStatus;
import com.capgemini.capstore.util.OrderStatus;

public interface DeliveryStatusDao extends JpaRepository<DeliveryStatus, Long> {

	@Query("FROM DeliveryStatus as s WHERE s.order.invoice.customer.customerId =?1 and s.status = ?2")
	List<DeliveryStatus> getDeliverd(long customerId, OrderStatus status);

	@Query("select s.order.invoice.customer from DeliveryStatus as s where s.id=?1")
	DeliveryStatus getCustomerByDeliveryStatus(Long id);

	@Query("From DeliveryStatus as s where s.order.invoice.customer.customerId =?1")
	List<DeliveryStatus> getDeliveryOrder(long customerId);

}
