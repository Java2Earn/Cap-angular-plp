package com.capgemini.capstore.util;

import java.util.Date;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.capgemini.capstore.exception.CartNotFoundException;
import com.capgemini.capstore.exception.CustomerCreationException;
import com.capgemini.capstore.exception.CustomerNotFoundException;
import com.capgemini.capstore.exception.MerchantNotFoundException;
import com.capgemini.capstore.exception.ProductFeedBackException;
import com.capgemini.capstore.exception.ProductNotFoundException;
import com.capgemini.capstore.exception.StockNotPresentException;
import com.capgemini.capstore.exception.WishListNotFoundException;

@ControllerAdvice
public class CustomerExceptionHandler extends ResponseEntityExceptionHandler {

	@ExceptionHandler(CustomerNotFoundException.class)
	public final ResponseEntity<CustomerExceptionResponse> handleWrongUserInputException(CustomerNotFoundException ex,
			WebRequest req) {

		CustomerExceptionResponse exceptionResponse = new CustomerExceptionResponse(new Date(), ex.getMessage(),

				req.getDescription(false), HttpStatus.BAD_REQUEST.getReasonPhrase());

		return new ResponseEntity<CustomerExceptionResponse>(exceptionResponse, HttpStatus.BAD_REQUEST);

	}
	@ExceptionHandler(StockNotPresentException.class)
	public final ResponseEntity<CustomerExceptionResponse> handleWrongUserInputException(StockNotPresentException ex,
			WebRequest req) {

		CustomerExceptionResponse exceptionResponse = new CustomerExceptionResponse(new Date(), ex.getMessage(),

				req.getDescription(false), HttpStatus.BAD_REQUEST.getReasonPhrase());

		return new ResponseEntity<CustomerExceptionResponse>(exceptionResponse, HttpStatus.BAD_REQUEST);

	}
	@ExceptionHandler(ProductNotFoundException.class)
	public final ResponseEntity<CustomerExceptionResponse> handleWrongUserInputException(ProductNotFoundException ex,
			WebRequest req) {

		CustomerExceptionResponse exceptionResponse = new CustomerExceptionResponse(new Date(), ex.getMessage(),

				req.getDescription(false), HttpStatus.BAD_REQUEST.getReasonPhrase());

		return new ResponseEntity<CustomerExceptionResponse>(exceptionResponse, HttpStatus.BAD_REQUEST);

	}
	@ExceptionHandler(MerchantNotFoundException.class)
	public final ResponseEntity<CustomerExceptionResponse> handleWrongUserInputException(MerchantNotFoundException ex,
			WebRequest req) {

		CustomerExceptionResponse exceptionResponse = new CustomerExceptionResponse(new Date(), ex.getMessage(),

				req.getDescription(false), HttpStatus.BAD_REQUEST.getReasonPhrase());

		return new ResponseEntity<CustomerExceptionResponse>(exceptionResponse, HttpStatus.BAD_REQUEST);

	}
	@ExceptionHandler(CustomerCreationException.class)
	public final ResponseEntity<CustomerExceptionResponse> handleWrongUserInputException(CustomerCreationException ex,
			WebRequest req) {

		CustomerExceptionResponse exceptionResponse = new CustomerExceptionResponse(new Date(), ex.getMessage(),

				req.getDescription(false), HttpStatus.BAD_REQUEST.getReasonPhrase());

		return new ResponseEntity<CustomerExceptionResponse>(exceptionResponse, HttpStatus.BAD_REQUEST);

	}
	@ExceptionHandler(CartNotFoundException.class)
	public final ResponseEntity<CustomerExceptionResponse> handleWrongUserInputException(CartNotFoundException ex,
			WebRequest req) {

		CustomerExceptionResponse exceptionResponse = new CustomerExceptionResponse(new Date(), ex.getMessage(),

				req.getDescription(false), HttpStatus.BAD_REQUEST.getReasonPhrase());

		return new ResponseEntity<CustomerExceptionResponse>(exceptionResponse, HttpStatus.BAD_REQUEST);

	}
	@ExceptionHandler(WishListNotFoundException.class)
	public final ResponseEntity<CustomerExceptionResponse> handleWrongUserInputException(WishListNotFoundException ex,
			WebRequest req) {

		CustomerExceptionResponse exceptionResponse = new CustomerExceptionResponse(new Date(), ex.getMessage(),

				req.getDescription(false), HttpStatus.BAD_REQUEST.getReasonPhrase());

		return new ResponseEntity<CustomerExceptionResponse>(exceptionResponse, HttpStatus.BAD_REQUEST);
	}
	@ExceptionHandler(ProductFeedBackException.class)
	public final ResponseEntity<CustomerExceptionResponse> handleWrongUserInputException(ProductFeedBackException ex,
			WebRequest req) {

		CustomerExceptionResponse exceptionResponse = new CustomerExceptionResponse(new Date(), ex.getMessage(),

				req.getDescription(false), HttpStatus.BAD_REQUEST.getReasonPhrase());

		return new ResponseEntity<CustomerExceptionResponse>(exceptionResponse, HttpStatus.BAD_REQUEST);
	}

}