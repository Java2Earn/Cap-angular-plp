package com.capgemini.capstore.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.capstore.beans.Customer;
import com.capgemini.capstore.beans.DeliveryStatus;
import com.capgemini.capstore.beans.MerchantFeedback;
import com.capgemini.capstore.beans.Order;
import com.capgemini.capstore.beans.Product;
import com.capgemini.capstore.beans.Cart;
import com.capgemini.capstore.beans.ProductFeedback;
import com.capgemini.capstore.beans.WishList;
import com.capgemini.capstore.service.CustomerService;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/Customer")
public class CustomerController {

	@Autowired
	CustomerService custService;

	@PostMapping("/CreateAccount")
	@CrossOrigin(origins = "http://localhost:4200")
	public boolean createAccount(@RequestBody Customer cust) {
		return custService.createAccount(cust);
	}

	@PostMapping("/AddProduct")
	@CrossOrigin(origins = "http://localhost:4200")
	public boolean addProduct(@RequestBody Product product) {
		boolean res = custService.addProduct(product);
		return res;
	}

	@PutMapping("/EditCustomerProfile/{customerId}/{customerName}/{customerContactNo}/{customerAddress}")
	@CrossOrigin(origins = "http://localhost:4200")
	public void editCustProfile(@PathVariable Long customerId, @PathVariable String customerName,
			@PathVariable String customerContactNo, @PathVariable String customerAddress) {
		custService.editCustProfile(customerId, customerName, customerContactNo, customerAddress);
	}

	@PostMapping("/FeedBack/Merchant")
	@CrossOrigin(origins = "http://localhost:4200")
	public boolean merchantFeedback(@RequestBody MerchantFeedback merch) {
		return custService.merchantFeedback(merch);
	}

	@PostMapping("/FeedBack/Product/{productId}/{customerId}/{feedBack}/{rating}")
	@CrossOrigin(origins = "http://localhost:4200")
	public ProductFeedback productFeedback(@PathVariable long productId, @PathVariable long customerId,
			@PathVariable String feedBack, @PathVariable int rating) {
		return custService.productFeedback(productId, customerId, feedBack, rating);
	}

	@DeleteMapping("/Cart/DeleteFromCart/{cartId}")
	@CrossOrigin(origins = "http://localhost:4200")
	public void deleteCartProduct(@PathVariable Long cartId) {
		custService.deleteCartProduct(cartId);
	}

	@PostMapping("/Cart/AddToCartFromProductPage/{customerId}/{productId}") /* Working */
	@CrossOrigin(origins = "http://localhost:4200")
	public void addToCartFromProductPage(@PathVariable Long customerId, @PathVariable Long productId) {
		custService.addToCartFromProductPage(customerId, productId);
	}

	@PostMapping("/WishList/AddToWishListFromProductPage/{customerId}/{productId}") /* Working */
	@CrossOrigin(origins = "http://localhost:4200")
	public void addtoWishListFromProductPage(@PathVariable Long customerId, @PathVariable Long productId) {
		custService.addtoWishListFromProductPage(customerId, productId);
	}

	@PostMapping("/Cart/AddToCartFromWishList/{wishlistId}") /* Working */
	@CrossOrigin(origins = "http://localhost:4200")
	public void addToCartFromWishList(@PathVariable Long wishlistId) {
		custService.addToCartFromWishList(wishlistId);
	}

	@PostMapping("/WishList/AddToWishListFromCart/{cartId}") /* Working */
	@CrossOrigin(origins = "http://localhost:4200")
	public void addToWishListFromCart(@PathVariable Long cartId) {
		custService.addToWishListFromCart(cartId);
	}

	@DeleteMapping("/DeleteFromWish/{wishlistId}")	/* Working */
	@CrossOrigin(origins = "http://localhost:4200")
	public void deleteFromWishList(@PathVariable Long wishlistId) {
		custService.deleteFromWishList(wishlistId);
	}

	@GetMapping("/Cart/ShowAllCartProducts/{customerId}")	/* Working */
	@CrossOrigin(origins = "http://localhost:4200")
	public List<Cart> findAllCartProductsById(@PathVariable Long customerId) {
		System.out.println(custService.findAllCartProductsById(customerId));
		return custService.findAllCartProductsById(customerId);
	}

	@RequestMapping("/getwishlist/{customerId}")	/* Working */
	@CrossOrigin(origins = "http://localhost:4200")
	public List<WishList> getWishItemById(@PathVariable Long customerId) {
		System.out.println(custService.getWishListById(customerId));
		return custService.getWishListById(customerId);
	}

	/*-------------------------------------------------------------------------------*/

	@GetMapping("/GetOrders/{customerId}")		/* Working */
	@CrossOrigin(origins = "http://localhost:4200")
	public List<Order> getOrders(@PathVariable long customerId) {
		return custService.getAllOrder(customerId);
	}

	@GetMapping("/GetDeliveryOrder/{customerId}")		/* Working */
	@CrossOrigin(origins = "http://localhost:4200")
	public List<DeliveryStatus> getDeliveryOrder(@PathVariable long customerId) {
		return custService.getDeliveryOrder(customerId);
	}

	@GetMapping("/ReturnFromDelivery/{id}/{customerId}")
	@CrossOrigin(origins = "http://localhost:4200")
	public DeliveryStatus returnFromDelivery(@PathVariable long id, @PathVariable long customerId) throws Exception {
		return custService.returnFromDelivery(id, customerId);
	}

	@GetMapping("/RefundSummary/{customerId}")		/* Working */
	@CrossOrigin(origins = "http://localhost:4200")
	public List<DeliveryStatus> refundSummary(@PathVariable long customerId) {
		return custService.refundSummary(customerId);
	}

	/*-------------------------------------------------------------------------------*/

}