package com.capgemini.capstore.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.capgemini.capstore.beans.AccountDetail;

public interface AccountDao extends JpaRepository<AccountDetail, String> {

	@Query("from AccountDetail as A where A.customer.customerId=?1")
	AccountDetail getAccountDetails(Long customerId);
}
