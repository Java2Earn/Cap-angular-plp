package com.capgemini.capstore.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.capgemini.capstore.beans.Order;

public interface OrderDao extends JpaRepository<Order, Long> {
	@Query("From Order as s where s.invoice.customer.customerId =?1")
	List<Order> getAllOrder(long customerId);

}
