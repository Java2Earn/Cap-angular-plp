package com.capgemini.capstore.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.capgemini.capstore.beans.Cart;

public interface CartDao extends JpaRepository<Cart, Long> {
	 @Query("SELECT c from Cart c where c.customer.customerId = ?1")
	 List<Cart> findCartByCustomerId(Long customerId);

}
